import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Set;

/**
 * Your implementation of various graph algorithms.
 *
 * Includes:
 *   - Depth-First Search (DFS)    — recursive, uses call stack
 *   - Dijkstra's Algorithm        — single-source shortest paths
 *   - Prim's Algorithm            — Minimum Spanning Tree
 */
public class GraphAlgorithms {

    /**
     * Performs a depth-first search on the given graph, starting from the given vertex.
     *
     * DFS visits vertices in depth-first order, backtracking when it reaches
     * a dead end or an already-visited vertex.
     * This implementation must be recursive (uses the call stack as the stack).
     *
     * @param <T>   the generic type of the data in the vertices
     * @param start the vertex to begin the DFS from
     * @param graph the graph to search
     * @return list of vertices visited in DFS order
     * @throws java.lang.IllegalArgumentException if start or graph is null, or start is not in graph
     */
    public static <T> List<Vertex<T>> dfs(Vertex<T> start, Graph<T> graph) {
        if (start == null || graph == null) {
            throw new IllegalArgumentException("Start vertex and graph cannot be null.");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("Start vertex is not in the graph.");
        }
        List<Vertex<T>> visited = new ArrayList<>();
        Set<Vertex<T>> visitedSet = new HashSet<>();
        dfsHelper(start, graph, visited, visitedSet);
        return visited;
    }

    /**
     * Recursive helper for DFS.
     *
     * @param <T>        generic type
     * @param current    the current vertex being visited
     * @param graph      the graph being traversed
     * @param visited    ordered list of visited vertices
     * @param visitedSet set for O(1) membership checks
     */
    private static <T> void dfsHelper(Vertex<T> current, Graph<T> graph,
                                       List<Vertex<T>> visited, Set<Vertex<T>> visitedSet) {
        // Mark current vertex as visited
        visitedSet.add(current);
        visited.add(current);
        // Recurse on all unvisited neighbors
        for (VertexDistance<T> neighbor : graph.getAdjList().get(current)) {
            if (!visitedSet.contains(neighbor.getVertex())) {
                dfsHelper(neighbor.getVertex(), graph, visited, visitedSet);
            }
        }
    }

    /**
     * Finds the shortest path from the start vertex to all other vertices
     * using Dijkstra's Algorithm (classic variant with a visited set).
     *
     * Uses a PriorityQueue of VertexDistance objects (ordered by cumulative distance).
     * Terminates when PriorityQueue is empty OR all vertices have been visited.
     *
     * Only works for non-negative edge weights.
     *
     * @param <T>   the generic type of the data in the vertices
     * @param start the vertex to begin the algorithm from
     * @param graph the graph on which to run Dijkstra's
     * @return a Map of each vertex to its minimum distance from start
     * @throws java.lang.IllegalArgumentException if start or graph is null, or start is not in graph
     */
    public static <T> Map<Vertex<T>, Integer> dijkstras(Vertex<T> start, Graph<T> graph) {
        if (start == null || graph == null) {
            throw new IllegalArgumentException("Start vertex and graph cannot be null.");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("Start vertex is not in the graph.");
        }

        // Distance map: initialize all distances to infinity
        Map<Vertex<T>, Integer> distMap = new HashMap<>();
        for (Vertex<T> v : graph.getAdjList().keySet()) {
            distMap.put(v, Integer.MAX_VALUE);
        }
        distMap.put(start, 0);

        Set<Vertex<T>> visitedSet = new HashSet<>();
        // Priority queue ordered by cumulative distance (min-heap by default)
        PriorityQueue<VertexDistance<T>> pq = new PriorityQueue<>();
        pq.add(new VertexDistance<>(start, 0));

        while (!pq.isEmpty() && visitedSet.size() < graph.getAdjList().size()) {
            VertexDistance<T> current = pq.poll();
            Vertex<T> currentVertex = current.getVertex();
            int currentDist = current.getDistance();

            // Skip if already finalized
            if (visitedSet.contains(currentVertex)) {
                continue;
            }
            visitedSet.add(currentVertex);

            // Relax all outgoing edges from currentVertex
            for (VertexDistance<T> neighbor : graph.getAdjList().get(currentVertex)) {
                Vertex<T> neighborVertex = neighbor.getVertex();
                int newDist = currentDist + neighbor.getDistance();
                // If we found a shorter path, update and enqueue
                if (!visitedSet.contains(neighborVertex) && newDist < distMap.get(neighborVertex)) {
                    distMap.put(neighborVertex, newDist);
                    pq.add(new VertexDistance<>(neighborVertex, newDist));
                }
            }
        }
        return distMap;
    }

    /**
     * Finds the Minimum Spanning Tree (MST) using Prim's Algorithm.
     *
     * Starts from the given vertex and grows the MST greedily:
     * at each step, add the cheapest edge connecting the MST to a non-visited vertex.
     * Cycle detection is handled with a visited set.
     *
     * Since undirected edges are stored as two directed edges,
     * the resulting MST set will contain 2*(|V|-1) edges.
     *
     * Returns null if the MST cannot span all vertices (disconnected graph).
     *
     * @param <T>   the generic type of the data in the vertices
     * @param start the vertex to begin Prim's algorithm from
     * @param graph the graph on which to run Prim's
     * @return a Set of edges forming the MST, or null if no MST exists
     * @throws java.lang.IllegalArgumentException if start or graph is null, or start is not in graph
     */
    public static <T> Set<Edge<T>> prims(Vertex<T> start, Graph<T> graph) {
        if (start == null || graph == null) {
            throw new IllegalArgumentException("Start vertex and graph cannot be null.");
        }
        if (!graph.getAdjList().containsKey(start)) {
            throw new IllegalArgumentException("Start vertex is not in the graph.");
        }

        Set<Vertex<T>> visitedSet = new HashSet<>();
        Set<Edge<T>> mst = new HashSet<>();
        // Min-heap ordered by edge weight
        PriorityQueue<Edge<T>> pq = new PriorityQueue<>();

        // Seed the priority queue with all edges from the start vertex
        visitedSet.add(start);
        for (VertexDistance<T> neighbor : graph.getAdjList().get(start)) {
            pq.add(new Edge<>(start, neighbor.getVertex(), neighbor.getDistance()));
        }

        while (!pq.isEmpty() && visitedSet.size() < graph.getAdjList().size()) {
            Edge<T> minEdge = pq.poll();
            Vertex<T> dest = minEdge.getV();

            // Skip if destination is already in the MST (would create a cycle)
            if (visitedSet.contains(dest)) {
                continue;
            }
            visitedSet.add(dest);
            // Add both directions of the undirected edge to the MST set
            mst.add(minEdge);
            mst.add(new Edge<>(dest, minEdge.getU(), minEdge.getWeight()));

            // Add all edges from the newly added vertex to the priority queue
            for (VertexDistance<T> neighbor : graph.getAdjList().get(dest)) {
                if (!visitedSet.contains(neighbor.getVertex())) {
                    pq.add(new Edge<>(dest, neighbor.getVertex(), neighbor.getDistance()));
                }
            }
        }

        // If we couldn't visit all vertices, no spanning tree exists
        if (visitedSet.size() != graph.getAdjList().size()) {
            return null;
        }
        return mst;
    }
}
