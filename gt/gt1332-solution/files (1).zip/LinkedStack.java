/**
 * Your implementation of a LinkedStack backed by a singly linked list
 * without a tail reference.
 */
public class LinkedStack<T> {

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private LinkedNode<T> head;
    private int size;

    /**
     * Constructs a new LinkedStack.
     */
    public LinkedStack() {
        head = null;
        size = 0;
    }

    /**
     * Pushes the data onto the top of the stack.
     * Push to the front of the linked list for O(1) efficiency.
     *
     * @param data the data to push onto the stack
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void push(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot push null data onto the stack.");
        }
        // Create a new node that points to the current head (push to front)
        LinkedNode<T> newNode = new LinkedNode<>(data, head);
        head = newNode;
        size++;
    }

    /**
     * Removes and returns the data from the top of the stack (LIFO order).
     *
     * @return the data formerly at the top of the stack
     * @throws java.util.NoSuchElementException if the stack is empty
     */
    public T pop() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot pop from an empty stack.");
        }
        T removed = head.getData();
        head = head.getNext();
        size--;
        return removed;
    }

    /**
     * Returns the data from the top of the stack without removing it.
     *
     * @return the data from the top of the stack
     * @throws java.util.NoSuchElementException if the stack is empty
     */
    public T peek() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot peek an empty stack.");
        }
        return head.getData();
    }

    /**
     * Returns the head node of the stack.
     *
     * @return the node at the head of the stack
     */
    public LinkedNode<T> getHead() {
        return head;
    }

    /**
     * Returns the size of the stack.
     *
     * @return the size of the stack
     */
    public int size() {
        return size;
    }
}
