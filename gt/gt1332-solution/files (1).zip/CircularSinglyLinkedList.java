/**
 * Your implementation of a CircularSinglyLinkedList without a tail pointer.
 *
 * Key insight: The last node's next always points back to head (circular).
 * To efficiently add to the back in O(1), we keep a head reference and
 * traverse to the node just before head (i.e., the last node) via head's
 * previous... but since there is no tail, we use a trick:
 * - addToBack: add at head position but then advance head forward, so the
 *   new node effectively becomes the last node.
 */
public class CircularSinglyLinkedList<T> {

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private CircularSinglyLinkedListNode<T> head;
    private int size;

    /**
     * Constructs a new CircularSinglyLinkedList.
     */
    public CircularSinglyLinkedList() {
        head = null;
        size = 0;
    }

    /**
     * Adds the data to the specified index.
     *
     * For index 0 (front), use the trick of adding at the back then moving head.
     * For other indices, traverse to find the node just before the target index.
     *
     * @param index the index at which to add the new element
     * @param data  the data to add at the specified index
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index > size
     * @throws java.lang.IllegalArgumentException  if data is null
     */
    public void addAtIndex(int index, T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot insert null data into data structure.");
        }
        if (index < 0 || index > size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for size " + size + ".");
        }
        if (index == 0) {
            addToFront(data);
        } else {
            // Traverse to the node just before the target index
            CircularSinglyLinkedListNode<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.getNext();
            }
            // Insert new node between current and current.next
            CircularSinglyLinkedListNode<T> newNode = new CircularSinglyLinkedListNode<>(data, current.getNext());
            current.setNext(newNode);
            size++;
        }
    }

    /**
     * Adds the data to the front of the list.
     *
     * Trick: To add at the front in O(1) without a tail reference,
     * we add the new node at head's position but store the old head data
     * in the new node, put the new data in head, then advance next pointers.
     * Equivalently: create node after head, copy head's data there, put new data in head.
     *
     * @param data the data to add to the front of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToFront(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot insert null data into data structure.");
        }
        if (head == null) {
            // Empty list: create a single node pointing to itself
            head = new CircularSinglyLinkedListNode<>(data);
            head.setNext(head);
        } else {
            // Create a new node that copies the current head's data
            // Insert the new node right after head, then copy head's data to new node
            // and put new data into head — effectively head becomes the new front
            CircularSinglyLinkedListNode<T> newNode = new CircularSinglyLinkedListNode<>(head.getData(), head.getNext());
            head.setData(data);
            head.setNext(newNode);
        }
        size++;
    }

    /**
     * Adds the data to the back of the list in O(1) time.
     *
     * Trick: addToFront then advance head to the next node, so the newly
     * added node appears at the tail.
     *
     * @param data the data to add to the back of the list
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void addToBack(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot insert null data into data structure.");
        }
        // Use addToFront trick, then advance head so the new node is at the back
        addToFront(data);
        // After addToFront, data is at head. Advancing head makes data at tail.
        head = head.getNext();
    }

    /**
     * Removes and returns the element at the specified index.
     *
     * @param index the index of the element to remove
     * @return the data formerly located at the specified index
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T removeAtIndex(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for size " + size + ".");
        }
        if (index == 0) {
            return removeFromFront();
        } else {
            // Traverse to the node just before the target
            CircularSinglyLinkedListNode<T> current = head;
            for (int i = 0; i < index - 1; i++) {
                current = current.getNext();
            }
            T removed = current.getNext().getData();
            current.setNext(current.getNext().getNext());
            size--;
            return removed;
        }
    }

    /**
     * Removes and returns the first element of the list in O(1) time.
     *
     * Trick: copy next node's data into head, then skip the next node.
     *
     * @return the data formerly located at the front of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromFront() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot remove from an empty list.");
        }
        T removed = head.getData();
        if (size == 1) {
            // Only one node: set head to null
            head = null;
        } else {
            // Copy next node's data into head, then skip next node
            head.setData(head.getNext().getData());
            head.setNext(head.getNext().getNext());
        }
        size--;
        return removed;
    }

    /**
     * Removes and returns the last element of the list.
     *
     * This is O(n) because we must traverse to the second-to-last node.
     *
     * @return the data formerly located at the back of the list
     * @throws java.util.NoSuchElementException if the list is empty
     */
    public T removeFromBack() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot remove from an empty list.");
        }
        return removeAtIndex(size - 1);
    }

    /**
     * Returns the element at the specified index.
     *
     * @param index the index of the element to get
     * @return the data stored at the index in the list
     * @throws java.lang.IndexOutOfBoundsException if index < 0 or index >= size
     */
    public T get(int index) {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Index " + index + " is out of bounds for size " + size + ".");
        }
        CircularSinglyLinkedListNode<T> current = head;
        for (int i = 0; i < index; i++) {
            current = current.getNext();
        }
        return current.getData();
    }

    /**
     * Returns whether or not the list is empty.
     *
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Clears the list.
     */
    public void clear() {
        head = null;
        size = 0;
    }

    /**
     * Removes and returns the last copy of the given data from the list.
     *
     * @param data the data to be removed from the list
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if data is not found
     */
    public T removeLastOccurrence(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot search for null data in data structure.");
        }
        // Track the node just before the last occurrence found
        CircularSinglyLinkedListNode<T> lastPrev = null;
        CircularSinglyLinkedListNode<T> current = head;
        boolean isHeadMatch = false;

        for (int i = 0; i < size; i++) {
            CircularSinglyLinkedListNode<T> next = current.getNext();
            if (next.getData().equals(data) && i < size - 1) {
                lastPrev = current;
            }
            current = next;
        }
        // Also check head itself
        if (head.getData().equals(data)) {
            isHeadMatch = true;
        }

        if (lastPrev == null && !isHeadMatch) {
            throw new java.util.NoSuchElementException("Data " + data + " was not found in the list.");
        }

        if (lastPrev != null) {
            // The last occurrence is lastPrev.next
            T removed = lastPrev.getNext().getData();
            lastPrev.setNext(lastPrev.getNext().getNext());
            size--;
            return removed;
        } else {
            // The only occurrence is at head
            return removeFromFront();
        }
    }

    /**
     * Returns an array representation of the linked list.
     *
     * @return the array of length size holding all the data in the list in the
     * same order as the list
     */
    public T[] toArray() {
        T[] arr = (T[]) new Object[size];
        CircularSinglyLinkedListNode<T> current = head;
        for (int i = 0; i < size; i++) {
            arr[i] = current.getData();
            current = current.getNext();
        }
        return arr;
    }

    /**
     * Returns the head node of the list.
     *
     * @return the node at the head of the list
     */
    public CircularSinglyLinkedListNode<T> getHead() {
        return head;
    }

    /**
     * Returns the size of the list.
     *
     * @return the size of the list
     */
    public int size() {
        return size;
    }
}
