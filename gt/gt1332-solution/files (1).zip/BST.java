import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Your implementation of a Binary Search Tree (BST).
 */
public class BST<T extends Comparable<? super T>> {

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private BSTNode<T> root;
    private int size;

    /**
     * Constructs a new BST.
     */
    public BST() {
        root = null;
        size = 0;
    }

    /**
     * Constructs a new BST. This constructor initializes the BST with the
     * data in the Collection. The data is added in the same order it is
     * in the collection.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data or any element in data is null
     */
    public BST(Collection<T> data) {
        this();
        if (data == null) {
            throw new IllegalArgumentException("Cannot construct BST from null collection.");
        }
        for (T item : data) {
            add(item);
        }
    }

    /**
     * Adds the data to the tree.
     * The data becomes a leaf in the tree. Duplicate data is ignored.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void add(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot add null data to BST.");
        }
        root = addHelper(root, data);
    }

    /**
     * Recursive helper for add using pointer reinforcement.
     *
     * @param node the current node in the recursion
     * @param data the data to insert
     * @return the node after insertion (used for pointer reinforcement)
     */
    private BSTNode<T> addHelper(BSTNode<T> node, T data) {
        if (node == null) {
            // Base case: found the insertion spot
            size++;
            return new BSTNode<>(data);
        }
        int cmp = data.compareTo(node.getData());
        if (cmp < 0) {
            // Go left
            node.setLeft(addHelper(node.getLeft(), data));
        } else if (cmp > 0) {
            // Go right
            node.setRight(addHelper(node.getRight(), data));
        }
        // If cmp == 0, duplicate: do nothing
        return node;
    }

    /**
     * Removes and returns the data from the tree matching the given parameter.
     * Three cases: no children, one child, two children (use inorder successor).
     *
     * @param data the data to remove
     * @return the data that was removed
     * @throws java.lang.IllegalArgumentException  if data is null
     * @throws java.util.NoSuchElementException    if the data is not found
     */
    public T remove(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot remove null data from BST.");
        }
        // Use a dummy node to capture the removed value
        BSTNode<T> dummy = new BSTNode<>(null);
        root = removeHelper(root, data, dummy);
        return dummy.getData();
    }

    /**
     * Recursive helper for remove using pointer reinforcement.
     *
     * @param node    the current node
     * @param data    the data to remove
     * @param removed a dummy node used to store the removed data
     * @return the node after removal
     */
    private BSTNode<T> removeHelper(BSTNode<T> node, T data, BSTNode<T> removed) {
        if (node == null) {
            throw new java.util.NoSuchElementException("Data " + data + " not found in the BST.");
        }
        int cmp = data.compareTo(node.getData());
        if (cmp < 0) {
            node.setLeft(removeHelper(node.getLeft(), data, removed));
        } else if (cmp > 0) {
            node.setRight(removeHelper(node.getRight(), data, removed));
        } else {
            // Found the node to remove
            removed.setData(node.getData());
            size--;
            if (node.getLeft() == null) {
                // No left child: replace with right child (handles 0 and 1 child cases)
                return node.getRight();
            } else if (node.getRight() == null) {
                // No right child: replace with left child
                return node.getLeft();
            } else {
                // Two children: find inorder successor (smallest in right subtree)
                BSTNode<T> successorDummy = new BSTNode<>(null);
                node.setRight(removeSuccessor(node.getRight(), successorDummy));
                node.setData(successorDummy.getData());
            }
        }
        return node;
    }

    /**
     * Finds and removes the inorder successor (leftmost node in a subtree).
     *
     * @param node    the root of the subtree to search
     * @param dummy   stores the successor's data
     * @return the node after removing the successor
     */
    private BSTNode<T> removeSuccessor(BSTNode<T> node, BSTNode<T> dummy) {
        if (node.getLeft() == null) {
            // This is the leftmost node (inorder successor)
            dummy.setData(node.getData());
            return node.getRight();
        }
        node.setLeft(removeSuccessor(node.getLeft(), dummy));
        return node;
    }

    /**
     * Returns the data from the tree matching the given parameter.
     *
     * @param data the data to search for
     * @return the data in the tree equal to the parameter
     * @throws java.lang.IllegalArgumentException if data is null
     * @throws java.util.NoSuchElementException   if the data is not found
     */
    public T get(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot search for null data in BST.");
        }
        return getHelper(root, data);
    }

    /**
     * Recursive helper for get.
     *
     * @param node the current node
     * @param data the data to find
     * @return the data stored in the found node
     */
    private T getHelper(BSTNode<T> node, T data) {
        if (node == null) {
            throw new java.util.NoSuchElementException("Data " + data + " not found in the BST.");
        }
        int cmp = data.compareTo(node.getData());
        if (cmp < 0) {
            return getHelper(node.getLeft(), data);
        } else if (cmp > 0) {
            return getHelper(node.getRight(), data);
        }
        return node.getData();
    }

    /**
     * Returns whether or not data matching the given parameter is contained within the tree.
     *
     * @param data the data to search for
     * @return true if the parameter is contained within the tree, false otherwise
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public boolean contains(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot search for null data in BST.");
        }
        return containsHelper(root, data);
    }

    /**
     * Recursive helper for contains.
     *
     * @param node the current node
     * @param data the data to find
     * @return true if data is found, false otherwise
     */
    private boolean containsHelper(BSTNode<T> node, T data) {
        if (node == null) {
            return false;
        }
        int cmp = data.compareTo(node.getData());
        if (cmp < 0) {
            return containsHelper(node.getLeft(), data);
        } else if (cmp > 0) {
            return containsHelper(node.getRight(), data);
        }
        return true;
    }

    /**
     * Generate a pre-order traversal of the tree (root, left, right).
     *
     * @return the preorder traversal of the tree
     */
    public List<T> preorder() {
        List<T> result = new ArrayList<>();
        preorderHelper(root, result);
        return result;
    }

    /**
     * Recursive helper for preorder traversal.
     *
     * @param node   the current node
     * @param result the list being built
     */
    private void preorderHelper(BSTNode<T> node, List<T> result) {
        if (node == null) {
            return;
        }
        result.add(node.getData());       // Visit root first
        preorderHelper(node.getLeft(), result);
        preorderHelper(node.getRight(), result);
    }

    /**
     * Generate an in-order traversal of the tree (left, root, right).
     * For a BST this produces elements in sorted order.
     *
     * @return the inorder traversal of the tree
     */
    public List<T> inorder() {
        List<T> result = new ArrayList<>();
        inorderHelper(root, result);
        return result;
    }

    /**
     * Recursive helper for inorder traversal.
     *
     * @param node   the current node
     * @param result the list being built
     */
    private void inorderHelper(BSTNode<T> node, List<T> result) {
        if (node == null) {
            return;
        }
        inorderHelper(node.getLeft(), result);
        result.add(node.getData());       // Visit root in the middle
        inorderHelper(node.getRight(), result);
    }

    /**
     * Generate a post-order traversal of the tree (left, right, root).
     *
     * @return the postorder traversal of the tree
     */
    public List<T> postorder() {
        List<T> result = new ArrayList<>();
        postorderHelper(root, result);
        return result;
    }

    /**
     * Recursive helper for postorder traversal.
     *
     * @param node   the current node
     * @param result the list being built
     */
    private void postorderHelper(BSTNode<T> node, List<T> result) {
        if (node == null) {
            return;
        }
        postorderHelper(node.getLeft(), result);
        postorderHelper(node.getRight(), result);
        result.add(node.getData());       // Visit root last
    }

    /**
     * Generate a level-order traversal of the tree using a Queue (BFS).
     *
     * @return the level order traversal of the tree
     */
    public List<T> levelorder() {
        List<T> result = new ArrayList<>();
        if (root == null) {
            return result;
        }
        Queue<BSTNode<T>> queue = new LinkedList<>();
        queue.add(root);
        while (!queue.isEmpty()) {
            BSTNode<T> current = queue.poll();
            result.add(current.getData());
            if (current.getLeft() != null) {
                queue.add(current.getLeft());
            }
            if (current.getRight() != null) {
                queue.add(current.getRight());
            }
        }
        return result;
    }

    /**
     * Returns the height of the root of the tree.
     * A leaf node has height 0; null nodes have height -1.
     *
     * @return the height of the tree, -1 if the tree is empty
     */
    public int height() {
        return heightHelper(root);
    }

    /**
     * Recursive helper for height computation.
     *
     * @param node the current node
     * @return the height of the subtree rooted at node
     */
    private int heightHelper(BSTNode<T> node) {
        if (node == null) {
            return -1; // Null nodes have height -1
        }
        return Math.max(heightHelper(node.getLeft()), heightHelper(node.getRight())) + 1;
    }

    /**
     * Clears the tree.
     */
    public void clear() {
        root = null;
        size = 0;
    }

    /**
     * Finds the data from the maximum of the deepest leaf of the tree.
     * (Rightmost node at the greatest depth when there are ties.)
     *
     * @return the data in the maximum of the deepest leaf
     * @throws java.util.NoSuchElementException if the tree is empty
     */
    public T maxDeepestNode() {
        if (root == null) {
            throw new java.util.NoSuchElementException("Cannot find max deepest node in an empty tree.");
        }
        return maxDeepestHelper(root).getData();
    }

    /**
     * Recursive helper that returns the node corresponding to the max deepest node.
     * Uses height to determine which subtree is deeper.
     *
     * @param node the current node
     * @return the node representing the max deepest node in the subtree
     */
    private BSTNode<T> maxDeepestHelper(BSTNode<T> node) {
        if (node.getLeft() == null && node.getRight() == null) {
            // Leaf node
            return node;
        }
        int leftHeight = heightHelper(node.getLeft());
        int rightHeight = heightHelper(node.getRight());
        if (leftHeight > rightHeight) {
            return maxDeepestHelper(node.getLeft());
        } else {
            // Right is deeper or equal: go right (right = max when tied)
            return maxDeepestHelper(node.getRight());
        }
    }

    /**
     * Returns the root of the tree.
     *
     * @return the root of the tree
     */
    public BSTNode<T> getRoot() {
        return root;
    }

    /**
     * Returns the size of the tree.
     *
     * @return the number of elements in the tree
     */
    public int size() {
        return size;
    }
}
