/**
 * Your implementation of an ArrayQueue backed by a circular array.
 */
public class ArrayQueue<T> {

    /*
     * The initial capacity of the ArrayQueue.
     * DO NOT MODIFY THIS VARIABLE.
     */
    public static final int INITIAL_CAPACITY = 9;

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private T[] backingArray;
    private int front;
    private int size;

    /**
     * Constructs a new ArrayQueue.
     */
    public ArrayQueue() {
        backingArray = (T[]) new Object[INITIAL_CAPACITY];
        front = 0;
        size = 0;
    }

    /**
     * Adds the data to the back of the queue.
     *
     * If the array is full, double its capacity. When resizing, realign
     * front to index 0 of the new array.
     *
     * @param data the data to add to the back of the queue
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void enqueue(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot insert null data into data structure.");
        }
        // Resize if needed, unwrapping the circular array
        if (size == backingArray.length) {
            T[] newArray = (T[]) new Object[backingArray.length * 2];
            for (int i = 0; i < size; i++) {
                // Map old circular index to new linear index
                newArray[i] = backingArray[(front + i) % backingArray.length];
            }
            backingArray = newArray;
            front = 0;
        }
        // Compute the back index using circular arithmetic
        int backIndex = (front + size) % backingArray.length;
        backingArray[backIndex] = data;
        size++;
    }

    /**
     * Removes and returns the data from the front of the queue.
     *
     * Do NOT shift elements during a remove. Do NOT reset front to 0
     * when the queue becomes empty.
     *
     * @return the data formerly located at the front of the queue
     * @throws java.util.NoSuchElementException if the queue is empty
     */
    public T dequeue() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot dequeue from an empty queue.");
        }
        T removed = backingArray[front];
        // Null out the old front slot
        backingArray[front] = null;
        // Advance front circularly
        front = (front + 1) % backingArray.length;
        size--;
        return removed;
    }

    /**
     * Returns the data from the front of the queue without removing it.
     *
     * @return the data located at the front of the queue
     * @throws java.util.NoSuchElementException if the queue is empty
     */
    public T peek() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot peek an empty queue.");
        }
        return backingArray[front];
    }

    /**
     * Returns the backing array of the queue.
     *
     * @return the backing array of the queue
     */
    public T[] getBackingArray() {
        return backingArray;
    }

    /**
     * Returns the size of the queue.
     *
     * @return the size of the queue
     */
    public int size() {
        return size;
    }
}
