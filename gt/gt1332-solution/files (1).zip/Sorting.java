import java.util.Comparator;
import java.util.Random;
import java.util.LinkedList;

/**
 * Your implementation of various sorting algorithms.
 *
 * All sorts (except LSD radix) use a Comparator for element comparison.
 * LSD radix sort operates on int arrays.
 */
public class Sorting {

    /**
     * Implement insertion sort.
     *
     * In-place, stable, and adaptive.
     * Worst case: O(n^2), Best case: O(n).
     *
     * Sort from the beginning: after pass k, indices 0..k are sorted.
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is null
     */
    public static <T> void insertionSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Array and comparator cannot be null.");
        }
        for (int i = 1; i < arr.length; i++) {
            int j = i;
            // Shift arr[j] left until it is in the correct sorted position
            while (j > 0 && comparator.compare(arr[j], arr[j - 1]) < 0) {
                T temp = arr[j];
                arr[j] = arr[j - 1];
                arr[j - 1] = temp;
                j--;
            }
        }
    }

    /**
     * Implement cocktail sort (bidirectional bubble sort).
     *
     * In-place, stable, and adaptive.
     * Worst case: O(n^2), Best case: O(n).
     * Uses last-swap-index optimization.
     *
     * @param <T>        data type to sort
     * @param arr        the array that must be sorted after the method runs
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is null
     */
    public static <T> void cocktailSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Array and comparator cannot be null.");
        }
        int start = 0;
        int end = arr.length - 1;
        boolean swapped = true;

        while (swapped) {
            swapped = false;
            int lastSwap = start; // Tracks last swap index on forward pass

            // Forward pass: bubble the largest unsorted element to the right
            for (int i = start; i < end; i++) {
                if (comparator.compare(arr[i], arr[i + 1]) > 0) {
                    T temp = arr[i];
                    arr[i] = arr[i + 1];
                    arr[i + 1] = temp;
                    swapped = true;
                    lastSwap = i;
                }
            }
            end = lastSwap; // Everything after lastSwap is sorted

            if (!swapped) {
                break;
            }
            swapped = false;
            lastSwap = end; // Reset for backward pass

            // Backward pass: bubble the smallest unsorted element to the left
            for (int i = end; i > start; i--) {
                if (comparator.compare(arr[i], arr[i - 1]) < 0) {
                    T temp = arr[i];
                    arr[i] = arr[i - 1];
                    arr[i - 1] = temp;
                    swapped = true;
                    lastSwap = i;
                }
            }
            start = lastSwap; // Everything before lastSwap is sorted
        }
    }

    /**
     * Implement merge sort.
     *
     * Out-of-place, stable, not adaptive.
     * Worst and best case: O(n log n).
     * When splitting an odd-size array, extra element goes to the right.
     *
     * @param <T>        data type to sort
     * @param arr        the array to be sorted
     * @param comparator the Comparator used to compare the data in arr
     * @throws java.lang.IllegalArgumentException if the array or comparator is null
     */
    public static <T> void mergeSort(T[] arr, Comparator<T> comparator) {
        if (arr == null || comparator == null) {
            throw new IllegalArgumentException("Array and comparator cannot be null.");
        }
        if (arr.length <= 1) {
            return; // Base case: already sorted
        }
        int mid = arr.length / 2;
        // Split into left and right subarrays
        T[] left = (T[]) new Object[mid];
        T[] right = (T[]) new Object[arr.length - mid];

        for (int i = 0; i < mid; i++) {
            left[i] = arr[i];
        }
        for (int i = mid; i < arr.length; i++) {
            right[i - mid] = arr[i];
        }
        // Recursively sort each half
        mergeSort(left, comparator);
        mergeSort(right, comparator);
        // Merge the sorted halves back into arr
        merge(arr, left, right, comparator);
    }

    /**
     * Merges two sorted subarrays (left and right) into the destination array.
     *
     * @param <T>        data type
     * @param arr        the destination array
     * @param left       the left sorted subarray
     * @param right      the right sorted subarray
     * @param comparator comparator for ordering
     */
    private static <T> void merge(T[] arr, T[] left, T[] right, Comparator<T> comparator) {
        int i = 0; // Pointer for left
        int j = 0; // Pointer for right
        int k = 0; // Pointer for arr

        while (i < left.length && j < right.length) {
            // Use <= to maintain stability (left wins ties)
            if (comparator.compare(left[i], right[j]) <= 0) {
                arr[k++] = left[i++];
            } else {
                arr[k++] = right[j++];
            }
        }
        // Copy remaining elements
        while (i < left.length) {
            arr[k++] = left[i++];
        }
        while (j < right.length) {
            arr[k++] = right[j++];
        }
    }

    /**
     * Implement LSD (Least Significant Digit) radix sort.
     *
     * Out-of-place, stable, not adaptive.
     * Worst and best case: O(kn), where k = number of digits in max value.
     * Sorts integers (including negatives) in base 10.
     * Do NOT convert ints to Strings. Only Math.abs() from Math class is allowed.
     *
     * @param arr the array to be sorted
     * @throws java.lang.IllegalArgumentException if the array is null
     */
    public static void lsdRadixSort(int[] arr) {
        if (arr == null) {
            throw new IllegalArgumentException("Array cannot be null.");
        }
        if (arr.length <= 1) {
            return;
        }
        // Find the maximum absolute value to determine the number of digits
        // Handle Integer.MIN_VALUE specially since Math.abs(Integer.MIN_VALUE) overflows
        int max = 0;
        for (int num : arr) {
            // Avoid overflow: if num == Integer.MIN_VALUE, use it as a special flag
            int absVal = (num == Integer.MIN_VALUE) ? Integer.MAX_VALUE : Math.abs(num);
            if (absVal > max) {
                max = absVal;
            }
        }
        // Determine the number of digits in the maximum value
        int numDigits = 0;
        int temp = max;
        while (temp > 0) {
            numDigits++;
            temp /= 10;
        }
        if (numDigits == 0) {
            numDigits = 1; // All zeros case
        }
        // If any element is Integer.MIN_VALUE, we need at least 10 digits
        for (int num : arr) {
            if (num == Integer.MIN_VALUE) {
                numDigits = Math.max(numDigits, 10);
                break;
            }
        }

        int divisor = 1; // Used to extract each digit position
        // Process each digit position from LSD to MSD
        for (int d = 0; d < numDigits; d++) {
            // Create 19 buckets: indices 0..17 represent digits -9 to 9
            // Use offset 9 so digit -9 goes to bucket 0, digit 0 to bucket 9, digit 9 to bucket 18
            LinkedList<Integer>[] buckets = new LinkedList[19];
            for (int i = 0; i < 19; i++) {
                buckets[i] = new LinkedList<>();
            }
            // Distribute elements into buckets based on current digit
            for (int num : arr) {
                int digit = (num / divisor) % 10; // Current digit (can be negative for negative numbers)
                buckets[digit + 9].add(num);       // Shift by 9 so -9 maps to index 0
            }
            // Collect elements from buckets back into arr
            int idx = 0;
            for (LinkedList<Integer> bucket : buckets) {
                for (int num : bucket) {
                    arr[idx++] = num;
                }
            }
            divisor *= 10;
        }
    }

    /**
     * Implement quick sort.
     *
     * In-place, unstable, not adaptive.
     * Worst case: O(n^2), Best case: O(n log n).
     * Uses randomized pivot selection to avoid worst-case behavior on sorted inputs.
     *
     * @param <T>        data type to sort
     * @param arr        the array to be sorted
     * @param comparator the Comparator used to compare the data in arr
     * @param rand       the Random object used to select pivots
     * @throws java.lang.IllegalArgumentException if the array, comparator, or rand is null
     */
    public static <T> void quickSort(T[] arr, Comparator<T> comparator, Random rand) {
        if (arr == null || comparator == null || rand == null) {
            throw new IllegalArgumentException("Array, comparator, and rand cannot be null.");
        }
        quickSortHelper(arr, comparator, rand, 0, arr.length - 1);
    }

    /**
     * Recursive helper for quicksort.
     * Partitions around a randomly chosen pivot and recurses on both halves.
     *
     * @param <T>        data type
     * @param arr        the array to sort
     * @param comparator comparator for ordering
     * @param rand       random number generator for pivot selection
     * @param left       the left boundary of the current partition (inclusive)
     * @param right      the right boundary of the current partition (inclusive)
     */
    private static <T> void quickSortHelper(T[] arr, Comparator<T> comparator, Random rand, int left, int right) {
        if (left >= right) {
            return; // Base case: one or zero elements
        }
        // Randomly select a pivot index and swap it to the front
        int pivotIdx = rand.nextInt(right - left + 1) + left;
        T pivot = arr[pivotIdx];
        arr[pivotIdx] = arr[left];
        arr[left] = pivot;

        int i = left + 1;
        int j = right;

        // Partition: move elements smaller than pivot to the left, larger to the right
        while (i <= j) {
            while (i <= j && comparator.compare(arr[i], pivot) <= 0) {
                i++;
            }
            while (i <= j && comparator.compare(arr[j], pivot) >= 0) {
                j--;
            }
            if (i <= j) {
                T temp = arr[i];
                arr[i] = arr[j];
                arr[j] = temp;
                i++;
                j--;
            }
        }
        // Place pivot in its final sorted position
        T temp = arr[left];
        arr[left] = arr[j];
        arr[j] = temp;

        // Recursively sort the two partitions
        quickSortHelper(arr, comparator, rand, left, j - 1);
        quickSortHelper(arr, comparator, rand, j + 1, right);
    }
}
