import java.util.ArrayList;

/**
 * Your implementation of a MaxHeap backed by an array.
 *
 * Index 0 of the array is always null (unused).
 * For a node at index i:
 *   - Left child  at 2i
 *   - Right child at 2i + 1
 *   - Parent      at i / 2
 */
public class MaxHeap<T extends Comparable<? super T>> {

    /*
     * The initial capacity of the MaxHeap when created with the default constructor.
     * DO NOT MODIFY THIS VARIABLE!
     */
    public static final int INITIAL_CAPACITY = 13;

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private T[] backingArray;
    private int size;

    /**
     * Constructs a new MaxHeap with the default initial capacity.
     */
    public MaxHeap() {
        backingArray = (T[]) new Comparable[INITIAL_CAPACITY];
        size = 0;
    }

    /**
     * Creates a properly ordered heap from a list of data using the BuildHeap algorithm.
     * This runs in O(n) time by starting from the last internal node and sifting down.
     *
     * @param data a list of data to initialize the heap with
     * @throws java.lang.IllegalArgumentException if data or any element in data is null
     */
    public MaxHeap(ArrayList<T> data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot build heap from null data.");
        }
        // Allocate 2n+1 capacity as per javadoc
        backingArray = (T[]) new Comparable[2 * data.size() + 1];
        size = data.size();
        // Copy data into array starting at index 1
        for (int i = 0; i < data.size(); i++) {
            if (data.get(i) == null) {
                throw new IllegalArgumentException("Cannot insert null element into heap.");
            }
            backingArray[i + 1] = data.get(i);
        }
        // BuildHeap: sift down from the last internal node up to the root
        // The last internal node is at index size/2
        for (int i = size / 2; i >= 1; i--) {
            siftDown(i);
        }
    }

    /**
     * Adds the given data to the heap.
     * Adds to the next available slot, then sifts up to restore the heap property.
     * Resizes to double capacity if needed.
     *
     * @param data the data to add
     * @throws java.lang.IllegalArgumentException if data is null
     */
    public void add(T data) {
        if (data == null) {
            throw new IllegalArgumentException("Cannot add null data to heap.");
        }
        // Resize if needed (size+1 because index 0 is unused)
        if (size + 1 >= backingArray.length) {
            T[] newArray = (T[]) new Comparable[backingArray.length * 2];
            for (int i = 0; i <= size; i++) {
                newArray[i] = backingArray[i];
            }
            backingArray = newArray;
        }
        // Place new element at the end
        backingArray[++size] = data;
        // Sift up to restore max-heap property
        siftUp(size);
    }

    /**
     * Removes and returns the root (maximum element) of the heap.
     * Replace root with the last element, then sift down.
     *
     * @return the data that was removed from the heap
     * @throws java.util.NoSuchElementException if the heap is empty
     */
    public T remove() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot remove from an empty heap.");
        }
        T max = backingArray[1];
        // Move the last element to the root
        backingArray[1] = backingArray[size];
        backingArray[size] = null;
        size--;
        // Sift down from root to restore heap property
        if (size > 0) {
            siftDown(1);
        }
        return max;
    }

    /**
     * Returns the maximum element (root) without removing it.
     *
     * @return the maximum element
     * @throws java.util.NoSuchElementException if the heap is empty
     */
    public T getMax() {
        if (size == 0) {
            throw new java.util.NoSuchElementException("Cannot get max from an empty heap.");
        }
        return backingArray[1];
    }

    /**
     * Returns whether or not the heap is empty.
     *
     * @return true if empty, false otherwise
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Clears the heap and resets to initial capacity.
     */
    public void clear() {
        backingArray = (T[]) new Comparable[INITIAL_CAPACITY];
        size = 0;
    }

    /**
     * Returns the backing array of the heap.
     *
     * @return the backing array of the heap
     */
    public T[] getBackingArray() {
        return backingArray;
    }

    /**
     * Returns the size of the heap.
     *
     * @return the size of the heap
     */
    public int size() {
        return size;
    }

    /**
     * Sifts the element at the given index upward until the heap property is restored.
     * Used after an add operation.
     *
     * @param index the index of the element to sift up
     */
    private void siftUp(int index) {
        while (index > 1) {
            int parentIdx = index / 2;
            if (backingArray[index].compareTo(backingArray[parentIdx]) > 0) {
                // Current element is larger than parent; swap them
                T temp = backingArray[index];
                backingArray[index] = backingArray[parentIdx];
                backingArray[parentIdx] = temp;
                index = parentIdx;
            } else {
                break; // Heap property is satisfied
            }
        }
    }

    /**
     * Sifts the element at the given index downward until the heap property is restored.
     * Used after a remove operation and during BuildHeap.
     *
     * @param index the index of the element to sift down
     */
    private void siftDown(int index) {
        while (2 * index <= size) {
            int leftChild = 2 * index;
            int rightChild = 2 * index + 1;
            // Find the larger of the two children
            int largerChild = leftChild;
            if (rightChild <= size && backingArray[rightChild].compareTo(backingArray[leftChild]) > 0) {
                largerChild = rightChild;
            }
            // If current node is smaller than the larger child, swap
            if (backingArray[index].compareTo(backingArray[largerChild]) < 0) {
                T temp = backingArray[index];
                backingArray[index] = backingArray[largerChild];
                backingArray[largerChild] = temp;
                index = largerChild;
            } else {
                break; // Heap property is satisfied
            }
        }
    }
}
