import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Your implementations of the three classic pattern matching algorithms:
 * Knuth-Morris-Pratt (KMP), Boyer-Moore, and Rabin-Karp.
 *
 * All algorithms find ALL occurrences of pattern in text,
 * returning a list of starting indices in ascending order.
 */
public class PatternMatching {

    /**
     * Knuth-Morris-Pratt (KMP) string searching algorithm.
     *
     * Builds a failure table from the pattern, then uses it to avoid
     * redundant comparisons during the search phase.
     *
     * @param pattern    the pattern string to search for
     * @param text       the text string to search in
     * @param comparator the CharacterComparator to count comparisons
     * @return list of starting indices where pattern occurs in text
     * @throws java.lang.IllegalArgumentException if pattern, text, or comparator is null, or pattern is empty
     */
    public static List<Integer> kmp(CharSequence pattern, CharSequence text, CharacterComparator comparator) {
        if (pattern == null || text == null || comparator == null) {
            throw new IllegalArgumentException("Pattern, text, and comparator cannot be null.");
        }
        if (pattern.length() == 0) {
            throw new IllegalArgumentException("Pattern cannot be empty.");
        }
        List<Integer> matches = new ArrayList<>();
        int m = pattern.length();
        int n = text.length();
        // If pattern is longer than text, no match is possible
        if (m > n) {
            return matches;
        }
        // Build the KMP failure table
        int[] failure = buildFailureTable(pattern, comparator);

        int i = 0; // Index into text
        int j = 0; // Index into pattern
        while (i <= n - m + j) {
            // Compare text[i] with pattern[j]
            if (comparator.compare(text.charAt(i), pattern.charAt(j)) == 0) {
                // Characters match
                i++;
                j++;
                if (j == m) {
                    // Full pattern matched; record the start index
                    matches.add(i - m);
                    // Use failure table to continue searching (treat match as mismatch)
                    j = failure[j - 1];
                }
            } else {
                // Mismatch
                if (j == 0) {
                    // Mismatch at beginning of pattern; just advance text pointer
                    i++;
                } else {
                    // Use failure table to shift pattern
                    j = failure[j - 1];
                }
            }
        }
        return matches;
    }

    /**
     * Builds the KMP failure table for the given pattern.
     *
     * failure[i] = length of the longest proper prefix of pattern[0..i]
     *              that is also a suffix of pattern[0..i].
     *
     * Algorithm:
     *   i starts at 0 (prefix pointer), j starts at 1 (suffix pointer).
     *   failure[0] is always 0.
     *
     * @param pattern    the pattern to build the failure table for
     * @param comparator the CharacterComparator for counting comparisons
     * @return the failure table as an int array of length pattern.length()
     */
    public static int[] buildFailureTable(CharSequence pattern, CharacterComparator comparator) {
        if (pattern == null || comparator == null) {
            throw new IllegalArgumentException("Pattern and comparator cannot be null.");
        }
        int m = pattern.length();
        int[] table = new int[m];
        table[0] = 0; // Always 0 for the first character
        int i = 0; // Prefix pointer
        int j = 1; // Suffix pointer

        while (j < m) {
            if (comparator.compare(pattern.charAt(i), pattern.charAt(j)) == 0) {
                // Prefix and suffix character match
                table[j] = i + 1;
                i++;
                j++;
            } else {
                // Mismatch
                if (i == 0) {
                    // Prefix pointer is at start; no match possible for position j
                    table[j] = 0;
                    j++;
                } else {
                    // Fall back using failure table (do NOT increment j)
                    i = table[i - 1];
                }
            }
        }
        return table;
    }

    /**
     * Boyer-Moore string searching algorithm.
     *
     * Builds a last occurrence table, then searches right-to-left within each window.
     * On a mismatch, shifts pattern based on the last occurrence table.
     *
     * @param pattern    the pattern string to search for
     * @param text       the text string to search in
     * @param comparator the CharacterComparator to count comparisons
     * @return list of starting indices where pattern occurs in text
     * @throws java.lang.IllegalArgumentException if pattern, text, or comparator is null, or pattern is empty
     */
    public static List<Integer> boyerMoore(CharSequence pattern, CharSequence text,
                                            CharacterComparator comparator) {
        if (pattern == null || text == null || comparator == null) {
            throw new IllegalArgumentException("Pattern, text, and comparator cannot be null.");
        }
        if (pattern.length() == 0) {
            throw new IllegalArgumentException("Pattern cannot be empty.");
        }
        List<Integer> matches = new ArrayList<>();
        int m = pattern.length();
        int n = text.length();
        if (m > n) {
            return matches;
        }
        // Build last occurrence table
        Map<Character, Integer> last = buildLastTable(pattern);

        int i = 0; // i is the start position of the pattern window in text
        while (i <= n - m) {
            int j = m - 1; // Compare from the end of the pattern
            // Scan pattern right-to-left
            while (j >= 0 && comparator.compare(text.charAt(i + j), pattern.charAt(j)) == 0) {
                j--;
            }
            if (j < 0) {
                // Full match found
                matches.add(i);
                // Shift pattern by one to continue searching
                i++;
            } else {
                // Mismatch at position j
                // Look up the last occurrence of the mismatched text character
                int lastOccurrence = last.getOrDefault(text.charAt(i + j), -1);
                if (lastOccurrence < j) {
                    // Shift pattern so last occurrence aligns with mismatched text char
                    i += j - lastOccurrence;
                } else {
                    // Last occurrence is to the right of mismatch; shift by 1 to avoid moving backward
                    i++;
                }
            }
        }
        return matches;
    }

    /**
     * Builds the last occurrence table for Boyer-Moore.
     *
     * Maps each character in the pattern to its LAST index in the pattern.
     * Characters not in the pattern are not included (getOrDefault returns -1).
     *
     * @param pattern the pattern to process
     * @return a Map from each character to its last index in the pattern
     */
    public static Map<Character, Integer> buildLastTable(CharSequence pattern) {
        if (pattern == null) {
            throw new IllegalArgumentException("Pattern cannot be null.");
        }
        Map<Character, Integer> last = new HashMap<>();
        for (int i = 0; i < pattern.length(); i++) {
            // Overwrite with the latest index; ensures we store the LAST occurrence
            last.put(pattern.charAt(i), i);
        }
        return last;
    }

    /**
     * Rabin-Karp string searching algorithm.
     *
     * Uses a rolling hash function to efficiently compare pattern hash with
     * text window hashes. Confirms matches with character-by-character comparison.
     *
     * Hash function (as specified in javadocs):
     *   hash = sum of (BASE^(m-1-i) * char[i]) for i in 0..m-1
     *   where BASE = 113
     *
     * Rolling update: hash_new = (hash_old - old_char * BASE^(m-1)) * BASE + new_char
     *
     * @param pattern    the pattern string to search for
     * @param text       the text string to search in
     * @param comparator the CharacterComparator to count comparisons
     * @return list of starting indices where pattern occurs in text
     * @throws java.lang.IllegalArgumentException if pattern, text, or comparator is null, or pattern is empty
     */
    public static List<Integer> rabinKarp(CharSequence pattern, CharSequence text,
                                           CharacterComparator comparator) {
        if (pattern == null || text == null || comparator == null) {
            throw new IllegalArgumentException("Pattern, text, and comparator cannot be null.");
        }
        if (pattern.length() == 0) {
            throw new IllegalArgumentException("Pattern cannot be empty.");
        }
        List<Integer> matches = new ArrayList<>();
        int m = pattern.length();
        int n = text.length();
        if (m > n) {
            return matches;
        }

        // BASE value as specified in javadocs
        int base = 113;

        // Compute BASE^(m-1) for rolling hash (without using Math.pow)
        int basePow = 1;
        for (int i = 0; i < m - 1; i++) {
            basePow *= base;
        }

        // Compute initial hash of pattern and first window of text
        int patternHash = 0;
        int textHash = 0;
        for (int i = 0; i < m; i++) {
            patternHash = patternHash * base + pattern.charAt(i);
            textHash = textHash * base + text.charAt(i);
        }

        // Slide the window across text
        for (int i = 0; i <= n - m; i++) {
            if (textHash == patternHash) {
                // Hash match: verify character by character
                int j = 0;
                while (j < m && comparator.compare(text.charAt(i + j), pattern.charAt(j)) == 0) {
                    j++;
                }
                if (j == m) {
                    matches.add(i);
                }
            }
            // Update rolling hash for the next window
            if (i < n - m) {
                textHash = (textHash - text.charAt(i) * basePow) * base + text.charAt(i + m);
            }
        }
        return matches;
    }
}
