import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Set;

/**
 * Your implementation of a HashMap with external chaining collision resolution.
 *
 * Keys are unique; values may be duplicated.
 * Collision resolution: each bucket holds a chain (linked list) of MapEntry objects.
 */
public class HashMap<K, V> {

    /*
     * The initial capacity of the HashMap (used by the default constructor).
     * DO NOT MODIFY this variable!
     */
    public static final int INITIAL_CAPACITY = 13;

    /*
     * The max load factor of the HashMap.
     * DO NOT MODIFY this variable!
     */
    public static final double MAX_LOAD_FACTOR = 0.67;

    /*
     * Do not add new instance variables or modify existing ones.
     */
    private MapEntry<K, V>[] table;
    private int size;

    /**
     * Constructs a new HashMap with the default initial capacity.
     * Uses constructor chaining.
     */
    public HashMap() {
        this(INITIAL_CAPACITY);
    }

    /**
     * Constructs a new HashMap with the specified initial capacity.
     *
     * @param initialCapacity the initial capacity of the backing table
     * @throws java.lang.IllegalArgumentException if initialCapacity is less than 1
     */
    public HashMap(int initialCapacity) {
        if (initialCapacity < 1) {
            throw new IllegalArgumentException("Initial capacity must be at least 1.");
        }
        table = (MapEntry<K, V>[]) new MapEntry[initialCapacity];
        size = 0;
    }

    /**
     * Adds the given key-value pair to the map.
     *
     * If the key already exists, replaces the value and returns the old value.
     * Resizes the backing array before adding if adding would exceed max load factor.
     * New entries are added to the FRONT of the chain at the computed index.
     *
     * @param key   the key to add
     * @param value the value to add
     * @return null if the key was not already in the map, or the old value if updated
     * @throws java.lang.IllegalArgumentException if key or value is null
     */
    public V put(K key, V value) {
        if (key == null || value == null) {
            throw new IllegalArgumentException("Key and value cannot be null.");
        }
        // Resize BEFORE adding if the new load factor would exceed MAX_LOAD_FACTOR
        if ((double) (size + 1) / table.length > MAX_LOAD_FACTOR) {
            resizeBackingTable(2 * table.length + 1);
        }
        // Compute index: mod then absolute value (in this order to prevent overflow)
        int index = Math.abs(key.hashCode() % table.length);
        // Search the chain at this index for a duplicate key
        MapEntry<K, V> current = table[index];
        while (current != null) {
            if (current.getKey().equals(key)) {
                // Key already exists: update value and return old value
                V oldValue = current.getValue();
                current.setValue(value);
                return oldValue;
            }
            current = current.getNext();
        }
        // Key not found: add new entry to the FRONT of the chain
        MapEntry<K, V> newEntry = new MapEntry<>(key, value, table[index]);
        table[index] = newEntry;
        size++;
        return null;
    }

    /**
     * Removes the entry with the matching key from the map and returns the value.
     *
     * @param key the key to remove
     * @return the value previously associated with the key
     * @throws java.lang.IllegalArgumentException if key is null
     * @throws java.util.NoSuchElementException   if the key is not in the map
     */
    public V remove(K key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        int index = Math.abs(key.hashCode() % table.length);
        MapEntry<K, V> current = table[index];
        MapEntry<K, V> prev = null;

        while (current != null) {
            if (current.getKey().equals(key)) {
                // Found the entry to remove
                if (prev == null) {
                    // Removing the head of the chain
                    table[index] = current.getNext();
                } else {
                    prev.setNext(current.getNext());
                }
                size--;
                return current.getValue();
            }
            prev = current;
            current = current.getNext();
        }
        throw new java.util.NoSuchElementException("Key " + key + " not found in HashMap.");
    }

    /**
     * Gets the value associated with the given key.
     *
     * @param key the key to search for in the map
     * @return the value associated with the given key
     * @throws java.lang.IllegalArgumentException if key is null
     * @throws java.util.NoSuchElementException   if the key is not in the map
     */
    public V get(K key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        int index = Math.abs(key.hashCode() % table.length);
        MapEntry<K, V> current = table[index];
        while (current != null) {
            if (current.getKey().equals(key)) {
                return current.getValue();
            }
            current = current.getNext();
        }
        throw new java.util.NoSuchElementException("Key " + key + " not found in HashMap.");
    }

    /**
     * Returns whether or not the key is in the map.
     *
     * @param key the key to search for in the map
     * @return true if the key is contained within the map, false otherwise
     * @throws java.lang.IllegalArgumentException if key is null
     */
    public boolean containsKey(K key) {
        if (key == null) {
            throw new IllegalArgumentException("Key cannot be null.");
        }
        int index = Math.abs(key.hashCode() % table.length);
        MapEntry<K, V> current = table[index];
        while (current != null) {
            if (current.getKey().equals(key)) {
                return true;
            }
            current = current.getNext();
        }
        return false;
    }

    /**
     * Returns a Set view of the keys contained in this map.
     * Uses Java's HashSet; this is permitted for the keySet/values methods.
     *
     * @return the set of keys in this map
     */
    public Set<K> keySet() {
        Set<K> keys = new HashSet<>();
        for (int i = 0; i < table.length; i++) {
            MapEntry<K, V> current = table[i];
            while (current != null) {
                keys.add(current.getKey());
                current = current.getNext();
            }
        }
        return keys;
    }

    /**
     * Returns a List of the values contained in this map.
     *
     * @return list of values in the map
     */
    public List<V> values() {
        List<V> vals = new LinkedList<>();
        for (int i = 0; i < table.length; i++) {
            MapEntry<K, V> current = table[i];
            while (current != null) {
                vals.add(current.getValue());
                current = current.getNext();
            }
        }
        return vals;
    }

    /**
     * Resizes the backing table to the given capacity and rehashes all entries.
     * All existing entries must be added to the new table.
     *
     * @param length the new length of the backing table
     * @throws java.lang.IllegalArgumentException if length is less than the number of elements in the map
     */
    public void resizeBackingTable(int length) {
        if (length < size) {
            throw new IllegalArgumentException("New capacity " + length + " is less than current size " + size + ".");
        }
        MapEntry<K, V>[] newTable = (MapEntry<K, V>[]) new MapEntry[length];
        // Rehash all existing entries into the new table
        for (int i = 0; i < table.length; i++) {
            MapEntry<K, V> current = table[i];
            while (current != null) {
                MapEntry<K, V> next = current.getNext();
                // Recompute index for new table length
                int newIndex = Math.abs(current.getKey().hashCode() % length);
                // Add to front of the chain at newIndex
                current.setNext(newTable[newIndex]);
                newTable[newIndex] = current;
                current = next;
            }
        }
        table = newTable;
    }

    /**
     * Returns the table of the map.
     *
     * @return the table of the map
     */
    public MapEntry<K, V>[] getTable() {
        return table;
    }

    /**
     * Returns the size of the map.
     *
     * @return the number of key-value pairs in the map
     */
    public int size() {
        return size;
    }
}
