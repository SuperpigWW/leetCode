"""
environment.py
==============
A lightweight 2-D Pick-and-Place simulation environment.

Why not use robosuite / MuJoCo?
  robosuite requires a C++ physics engine (MuJoCo) that is hard to install
  on some systems.  This pure-Python environment reproduces every concept
  needed for Level 1:
    - continuous state / action spaces
    - gripper open/close mechanics
    - success / failure detection
  …without any external simulator dependency.

State space  (7-dim):
  [arm_x, arm_y,          -- end-effector position  (0..1)
   obj_x, obj_y,          -- object position         (0..1)
   goal_x, goal_y,        -- goal zone centre        (0..1)
   gripper_state]         -- 0=open, 1=closed

Action space (3-dim):
  [delta_x, delta_y,      -- end-effector displacement  (-1..1, scaled)
   gripper_cmd]           -- <0 → open, >=0 → close
"""

import numpy as np
from dataclasses import dataclass
from typing import Tuple, Optional


# ── tuneable constants ────────────────────────────────────────
ARM_SPEED        = 0.05   # max displacement per step
GRIP_THRESHOLD   = 0.08   # distance to grab / release object
GOAL_RADIUS      = 0.10   # success zone radius
MAX_STEPS        = 100    # episode length cap
WORKSPACE        = (0.0, 1.0)  # x / y bounds
# ─────────────────────────────────────────────────────────────


@dataclass
class EnvConfig:
    arm_speed:      float = ARM_SPEED
    grip_threshold: float = GRIP_THRESHOLD
    goal_radius:    float = GOAL_RADIUS
    max_steps:      int   = MAX_STEPS
    seed:           Optional[int] = None


class PickAndPlaceEnv:
    """
    Lightweight 2-D Pick-and-Place environment.

    Observation: numpy array shape (7,)
    Action:      numpy array shape (3,)
    """

    OBS_DIM = 7
    ACT_DIM = 3

    def __init__(self, config: EnvConfig = EnvConfig()):
        self.cfg   = config
        self.rng   = np.random.default_rng(config.seed)
        self._step = 0

        # internal state (initialised in reset)
        self.arm_pos     = np.zeros(2)
        self.obj_pos     = np.zeros(2)
        self.goal_pos    = np.zeros(2)
        self.holding     = False
        self.gripper_val = 0.0   # 0=open, 1=closed

    # ── public API ────────────────────────────────────────────

    def reset(self) -> np.ndarray:
        """Reset episode; return initial observation."""
        self._step = 0
        self.holding = False
        self.gripper_val = 0.0

        # Randomise positions (keep object and goal apart)
        while True:
            self.arm_pos  = self.rng.uniform(0.1, 0.9, size=2)
            self.obj_pos  = self.rng.uniform(0.1, 0.9, size=2)
            self.goal_pos = self.rng.uniform(0.1, 0.9, size=2)
            # Ensure object and goal are not on top of each other
            if (np.linalg.norm(self.obj_pos - self.goal_pos) > 0.25 and
                    np.linalg.norm(self.arm_pos - self.obj_pos) > 0.15):
                break

        return self._get_obs()

    def step(self, action: np.ndarray) -> Tuple[np.ndarray, float, bool, dict]:
        """
        Apply action; return (obs, reward, done, info).

        Reward shaping (dense, for easier learning):
          +1.0  task success
          -0.01 per step (time penalty)
          +0.2  when object is picked up (one-time)
          shaped distance bonuses toward sub-goals
        """
        assert action.shape == (self.ACT_DIM,), \
            f"Expected action shape ({self.ACT_DIM},), got {action.shape}"

        self._step += 1
        reward = -0.01   # time penalty

        # ── 1. Move arm ───────────────────────────────────────
        delta = np.clip(action[:2], -1.0, 1.0) * self.cfg.arm_speed
        self.arm_pos = np.clip(self.arm_pos + delta, *WORKSPACE)

        # If holding the object, it moves with the arm
        if self.holding:
            self.obj_pos = self.arm_pos.copy()

        # ── 2. Gripper logic ──────────────────────────────────
        gripper_cmd = action[2]
        dist_to_obj = np.linalg.norm(self.arm_pos - self.obj_pos)

        if gripper_cmd >= 0:            # close gripper
            self.gripper_val = 1.0
            if (not self.holding) and dist_to_obj < self.cfg.grip_threshold:
                self.holding = True
                reward += 0.2           # pick-up bonus (once)
        else:                           # open gripper
            self.gripper_val = 0.0
            if self.holding:
                self.holding = False    # release object wherever arm is

        # ── 3. Distance-based shaping ─────────────────────────
        if not self.holding:
            # Reward getting close to the object
            reward += 0.05 * max(0, 1.0 - dist_to_obj / 0.5)
        else:
            # Reward getting close to the goal
            dist_to_goal = np.linalg.norm(self.obj_pos - self.goal_pos)
            reward += 0.05 * max(0, 1.0 - dist_to_goal / 0.5)

        # ── 4. Success check ─────────────────────────────────
        dist_obj_goal = np.linalg.norm(self.obj_pos - self.goal_pos)
        success = (dist_obj_goal < self.cfg.goal_radius) and (not self.holding)
        if success:
            reward += 1.0

        done = success or (self._step >= self.cfg.max_steps)
        info = {
            "success":       success,
            "steps":         self._step,
            "dist_to_obj":   float(dist_to_obj),
            "dist_obj_goal": float(dist_obj_goal),
            "holding":       self.holding,
        }
        return self._get_obs(), reward, done, info

    def render_ascii(self) -> str:
        """Return a 20×20 ASCII grid for quick debugging."""
        grid_size = 20
        grid = [["." for _ in range(grid_size)] for _ in range(grid_size)]

        def _to_grid(pos):
            r = int((1.0 - pos[1]) * (grid_size - 1))
            c = int(pos[0] * (grid_size - 1))
            return np.clip(r, 0, grid_size-1), np.clip(c, 0, grid_size-1)

        gr, gc = _to_grid(self.goal_pos)
        grid[gr][gc] = "G"

        if not self.holding:
            or_, oc = _to_grid(self.obj_pos)
            grid[or_][oc] = "O"

        ar, ac = _to_grid(self.arm_pos)
        grid[ar][ac] = "H" if self.holding else "A"

        lines = ["+" + "-" * grid_size + "+"]
        for row in grid:
            lines.append("|" + "".join(row) + "|")
        lines.append("+" + "-" * grid_size + "+")
        lines.append(f"Arm:{self.arm_pos.round(2)}  "
                     f"Obj:{self.obj_pos.round(2)}  "
                     f"Goal:{self.goal_pos.round(2)}  "
                     f"Hold:{self.holding}")
        return "\n".join(lines)

    # ── internal helpers ──────────────────────────────────────

    def _get_obs(self) -> np.ndarray:
        return np.array([
            self.arm_pos[0], self.arm_pos[1],
            self.obj_pos[0], self.obj_pos[1],
            self.goal_pos[0], self.goal_pos[1],
            self.gripper_val,
        ], dtype=np.float32)


# ── scripted expert policy ────────────────────────────────────

class ExpertPolicy:
    """
    Hand-crafted (scripted) expert for data collection.

    Phase 0: Move arm above the object
    Phase 1: Close gripper (grab object)
    Phase 2: Move arm above the goal
    Phase 3: Open gripper (release object)
    """

    def __init__(self, noise_std: float = 0.0):
        """
        Args:
            noise_std: Gaussian noise added to actions (0 = perfect expert).
                       Set > 0 to create sub-optimal demonstrations that test
                       the robustness of Behavior Cloning.
        """
        self.noise_std = noise_std
        self.phase     = 0

    def reset(self):
        self.phase = 0

    def act(self, obs: np.ndarray) -> np.ndarray:
        arm  = obs[0:2]
        obj  = obs[2:4]
        goal = obs[4:6]

        if self.phase == 0:
            # Move toward object
            direction = obj - arm
            dist = np.linalg.norm(direction)
            if dist > GRIP_THRESHOLD * 0.8:
                move = direction / (dist + 1e-8)
                action = np.array([move[0], move[1], -1.0])  # gripper open
            else:
                action = np.array([0.0, 0.0, -1.0])
                self.phase = 1

        elif self.phase == 1:
            # Close gripper to grab
            action = np.array([0.0, 0.0, 1.0])   # gripper close
            if obs[6] > 0.5:  # gripper is now closed
                self.phase = 2

        elif self.phase == 2:
            # Move toward goal while holding
            direction = goal - arm
            dist = np.linalg.norm(direction)
            if dist > GOAL_RADIUS * 0.8:
                move = direction / (dist + 1e-8)
                action = np.array([move[0], move[1], 1.0])  # keep holding
            else:
                action = np.array([0.0, 0.0, 1.0])
                self.phase = 3

        else:
            # Phase 3: open gripper to release
            action = np.array([0.0, 0.0, -1.0])

        # Optionally add noise
        if self.noise_std > 0:
            action[:2] += np.random.normal(0, self.noise_std, size=2)

        return action.astype(np.float32)


# ── quick smoke test ──────────────────────────────────────────

if __name__ == "__main__":
    print("=" * 50)
    print("  Environment smoke test")
    print("=" * 50)

    env    = PickAndPlaceEnv(EnvConfig(seed=42))
    expert = ExpertPolicy()

    obs    = env.reset()
    expert.reset()

    total_reward = 0.0
    for t in range(MAX_STEPS):
        action = expert.act(obs)
        obs, reward, done, info = env.step(action)
        total_reward += reward
        if done:
            status = "✅ SUCCESS" if info["success"] else "❌ TIMEOUT"
            print(f"  Episode ended at step {t+1}  {status}")
            print(f"  Total reward: {total_reward:.3f}")
            break

    print(env.render_ascii())
    print("  Environment test passed ✅")
