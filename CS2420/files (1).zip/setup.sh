#!/bin/bash
# ============================================================
# setup.sh — 一键安装所有依赖
# 运行方式：bash setup.sh
# ============================================================

echo ">>> [1/3] 创建虚拟环境 egomimic_level1 ..."
python3 -m venv egomimic_level1
source egomimic_level1/bin/activate

echo ">>> [2/3] 安装依赖..."
pip install --upgrade pip

# 核心深度学习框架
pip install torch torchvision torchaudio --index-url https://download.pytorch.org/whl/cpu

# 工具库
pip install numpy matplotlib tqdm einops scipy

echo ">>> [3/3] 验证安装..."
python3 -c "
import torch
import numpy as np
import matplotlib
import einops
print('✅ PyTorch:', torch.__version__)
print('✅ NumPy:', np.__version__)
print('✅ 所有依赖安装成功！')
print()
print('>>> 运行实验：')
print('    source egomimic_level1/bin/activate')
print('    python3 train.py')
print('    python3 evaluate.py')
"

echo ""
echo "=========================================="
echo "  安装完成！运行以下命令开始实验："
echo "  source egomimic_level1/bin/activate"
echo "  python3 train.py"
echo "=========================================="
