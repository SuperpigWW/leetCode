"""
train.py
========
Train the ACT policy using Behavior Cloning on expert demonstrations.

Loss function
-------------
  L_total = L_reconstruction + β * L_KL

  L_reconstruction: MSE between predicted action chunk and ground-truth chunk
  L_KL:             KL divergence between CVAE posterior and N(0,I) prior
                    (encourages the latent space to be compact and smooth)

Training strategy
-----------------
  - AdamW optimiser with cosine LR schedule
  - Gradient clipping to stabilise Transformer training
  - Validation split (10%) to detect overfitting
  - Checkpoint saved whenever validation loss improves
  - Full training curve saved to results/training_curves.npz
"""

import os
import time
import numpy as np
import torch
import torch.nn as nn
from torch.utils.data import Dataset, DataLoader, random_split
from torch.optim.lr_scheduler import CosineAnnealingLR
from act_model import ACTPolicy

# ── Hyperparameters ───────────────────────────────────────────
EPOCHS        = 100
BATCH_SIZE    = 64
LR            = 3e-4
WEIGHT_DECAY  = 1e-4
KL_WEIGHT     = 10.0    # β: weight on KL loss term
CHUNK_SIZE    = 10
D_MODEL       = 128
NHEAD         = 4
NUM_LAYERS    = 3
LATENT_DIM    = 32
VAL_SPLIT     = 0.1     # fraction of data used for validation
GRAD_CLIP     = 1.0     # max gradient norm

DATA_PATH     = "data/expert_demos.npz"
CKPT_DIR      = "checkpoints"
RESULTS_DIR   = "results"
CKPT_PATH     = os.path.join(CKPT_DIR, "best_model.pt")
# ─────────────────────────────────────────────────────────────


# ── Dataset ───────────────────────────────────────────────────

class DemoDataset(Dataset):
    """
    Wraps the expert demonstration data.
    Returns (obs, action_chunk) pairs, with observations normalised.
    """

    def __init__(self, data_path: str):
        data = np.load(data_path)
        self.obs     = torch.from_numpy(data["observations"])    # (N, obs_dim)
        self.chunks  = torch.from_numpy(data["action_chunks"])   # (N, K, act_dim)
        # Normalisation statistics (computed over full dataset)
        self.obs_mean = torch.from_numpy(data["obs_mean"])
        self.obs_std  = torch.from_numpy(data["obs_std"])

        # Apply normalisation
        self.obs = (self.obs - self.obs_mean) / self.obs_std

        print(f"  Dataset loaded: {len(self)} samples")
        print(f"  obs shape:    {self.obs.shape}")
        print(f"  chunk shape:  {self.chunks.shape}")

    def __len__(self):
        return len(self.obs)

    def __getitem__(self, idx):
        return self.obs[idx], self.chunks[idx]


# ── Training loop ─────────────────────────────────────────────

def train_epoch(model, loader, optimiser, device):
    """Run one training epoch; return (avg_total_loss, avg_recon_loss, avg_kl_loss)."""
    model.train()
    total_loss_sum = recon_loss_sum = kl_loss_sum = 0.0

    for obs_batch, chunk_batch in loader:
        obs_batch   = obs_batch.to(device)
        chunk_batch = chunk_batch.to(device)

        # Forward pass (training mode: CVAE encoder is used)
        pred_chunks, kl_loss = model(obs_batch, chunk_batch, is_training=True)

        # Reconstruction loss: MSE over entire action chunk
        recon_loss  = nn.functional.mse_loss(pred_chunks, chunk_batch)
        total_loss  = recon_loss + model.kl_weight * kl_loss

        # Backward pass
        optimiser.zero_grad()
        total_loss.backward()
        nn.utils.clip_grad_norm_(model.parameters(), GRAD_CLIP)
        optimiser.step()

        total_loss_sum += total_loss.item()
        recon_loss_sum += recon_loss.item()
        kl_loss_sum    += kl_loss.item()

    n = len(loader)
    return total_loss_sum / n, recon_loss_sum / n, kl_loss_sum / n


@torch.no_grad()
def val_epoch(model, loader, device):
    """Evaluate on validation set; return (avg_total_loss, avg_recon_loss)."""
    model.eval()
    total_loss_sum = recon_loss_sum = 0.0

    for obs_batch, chunk_batch in loader:
        obs_batch   = obs_batch.to(device)
        chunk_batch = chunk_batch.to(device)

        # Inference mode: z=0, no KL loss
        pred_chunks, _ = model(obs_batch, is_training=False)
        recon_loss      = nn.functional.mse_loss(pred_chunks, chunk_batch)
        total_loss_sum += recon_loss.item()
        recon_loss_sum += recon_loss.item()

    n = len(loader)
    return total_loss_sum / n, recon_loss_sum / n


# ── Main ──────────────────────────────────────────────────────

def main():
    os.makedirs(CKPT_DIR,    exist_ok=True)
    os.makedirs(RESULTS_DIR, exist_ok=True)

    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    print(f"\n{'='*55}")
    print(f"  ACT Behavior Cloning — Training")
    print(f"{'='*55}")
    print(f"  Device  : {device}")
    print(f"  Epochs  : {EPOCHS}")
    print(f"  Batch   : {BATCH_SIZE}")
    print(f"  LR      : {LR}")
    print(f"  KL β    : {KL_WEIGHT}")
    print(f"  Chunk K : {CHUNK_SIZE}")
    print()

    # ── Load data ─────────────────────────────────────────────
    dataset  = DemoDataset(DATA_PATH)
    val_size = int(len(dataset) * VAL_SPLIT)
    trn_size = len(dataset) - val_size
    trn_set, val_set = random_split(
        dataset, [trn_size, val_size],
        generator=torch.Generator().manual_seed(42)
    )
    trn_loader = DataLoader(trn_set, batch_size=BATCH_SIZE, shuffle=True,  num_workers=0)
    val_loader = DataLoader(val_set, batch_size=BATCH_SIZE, shuffle=False, num_workers=0)
    print(f"  Train samples: {trn_size}  |  Val samples: {val_size}\n")

    # ── Build model ───────────────────────────────────────────
    obs_dim    = dataset.obs.shape[1]
    action_dim = dataset.chunks.shape[2]

    model = ACTPolicy(
        obs_dim     = obs_dim,
        action_dim  = action_dim,
        chunk_size  = CHUNK_SIZE,
        d_model     = D_MODEL,
        nhead       = NHEAD,
        num_enc_layers = NUM_LAYERS,
        num_dec_layers = NUM_LAYERS,
        latent_dim  = LATENT_DIM,
        kl_weight   = KL_WEIGHT,
    ).to(device)

    num_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    print(f"  Model parameters: {num_params:,}")
    print()

    # ── Optimiser & scheduler ─────────────────────────────────
    optimiser = torch.optim.AdamW(model.parameters(), lr=LR, weight_decay=WEIGHT_DECAY)
    scheduler = CosineAnnealingLR(optimiser, T_max=EPOCHS, eta_min=LR * 0.01)

    # ── Training loop ─────────────────────────────────────────
    best_val_loss = float("inf")
    history = {
        "train_total": [], "train_recon": [], "train_kl": [],
        "val_total":   [], "val_recon":   [],
    }

    print(f"  {'Epoch':>5} | {'Train Loss':>10} | {'Recon':>8} | {'KL':>7} | "
          f"{'Val Loss':>9} | {'LR':>8} | {'Note'}")
    print("  " + "-" * 70)

    t0 = time.time()
    for epoch in range(1, EPOCHS + 1):
        trn_total, trn_recon, trn_kl = train_epoch(model, trn_loader, optimiser, device)
        val_total, val_recon          = val_epoch(model, val_loader, device)
        scheduler.step()

        history["train_total"].append(trn_total)
        history["train_recon"].append(trn_recon)
        history["train_kl"].append(trn_kl)
        history["val_total"].append(val_total)
        history["val_recon"].append(val_recon)

        # Save best model
        note = ""
        if val_total < best_val_loss:
            best_val_loss = val_total
            torch.save({
                "epoch":      epoch,
                "model_state_dict": model.state_dict(),
                "val_loss":   val_total,
                "obs_mean":   dataset.obs_mean,
                "obs_std":    dataset.obs_std,
                "config": {
                    "obs_dim": obs_dim, "action_dim": action_dim,
                    "chunk_size": CHUNK_SIZE, "d_model": D_MODEL,
                    "nhead": NHEAD, "num_layers": NUM_LAYERS,
                    "latent_dim": LATENT_DIM, "kl_weight": KL_WEIGHT,
                }
            }, CKPT_PATH)
            note = "✓ saved"

        cur_lr = scheduler.get_last_lr()[0]
        if epoch % 5 == 0 or epoch == 1 or note:
            print(f"  {epoch:>5} | {trn_total:>10.4f} | {trn_recon:>8.4f} | "
                  f"{trn_kl:>7.4f} | {val_total:>9.4f} | {cur_lr:>8.2e} | {note}")

    elapsed = time.time() - t0
    print(f"\n  Training complete in {elapsed:.0f}s")
    print(f"  Best val loss: {best_val_loss:.4f}")
    print(f"  Checkpoint saved to: {CKPT_PATH}")

    # ── Save training curves ──────────────────────────────────
    curves_path = os.path.join(RESULTS_DIR, "training_curves.npz")
    np.savez(curves_path, **{k: np.array(v) for k, v in history.items()})
    print(f"  Training curves saved to: {curves_path}")
    print(f"\n  Next step: python3 evaluate.py")


if __name__ == "__main__":
    main()
