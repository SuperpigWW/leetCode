"""
act_model.py
============
Action Chunking with Transformers (ACT) — the policy backbone used in EgoMimic.

Paper: "Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware"
       Tony Z. Zhao et al., RSS 2023  (the original ACT paper)

Core idea
---------
Instead of predicting one action at a time (standard BC), ACT predicts a
*chunk* of K future actions in one forward pass.  A Transformer encoder-decoder
architecture captures temporal dependencies, and a CVAE (Conditional VAE)
models the multi-modal nature of expert demonstrations.

Architecture overview
---------------------
                 ┌──────────────────────────────────────┐
  observation    │  ObsEncoder (MLP)                    │
  ──────────────►│  obs_dim → d_model                   │
                 └──────────────┬───────────────────────┘
                                │ encoder tokens
                                ▼
                 ┌──────────────────────────────────────┐
                 │  Transformer Encoder                  │
                 │  (self-attention over obs tokens)     │
                 └──────────────┬───────────────────────┘
                                │ memory
                                ▼
                 ┌──────────────────────────────────────┐
  query tokens   │  Transformer Decoder                  │
  ──────────────►│  (cross-attention: query ← memory)   │
  (chunk_size)   └──────────────┬───────────────────────┘
                                │
                                ▼
                 ┌──────────────────────────────────────┐
                 │  Action Head (Linear)                 │
                 │  d_model → action_dim  (per token)   │
                 └──────────────────────────────────────┘

CVAE latent variable z is concatenated to the observation tokens
during training (KL-regularisation loss term).
At inference, z is set to zero (mean of prior).
"""

import math
import torch
import torch.nn as nn
import torch.nn.functional as F
from typing import Optional, Tuple


# ──────────────────────────────────────────────────────────────
#  Positional Encoding
# ──────────────────────────────────────────────────────────────

class PositionalEncoding(nn.Module):
    """
    Standard sinusoidal positional encoding (Vaswani et al., 2017).
    Adds position information to token embeddings.
    """

    def __init__(self, d_model: int, max_len: int = 512, dropout: float = 0.1):
        super().__init__()
        self.dropout = nn.Dropout(dropout)

        # Compute the sinusoidal encoding table once
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len).unsqueeze(1).float()
        div_term = torch.exp(
            torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model)
        )
        pe[:, 0::2] = torch.sin(position * div_term)   # even dims
        pe[:, 1::2] = torch.cos(position * div_term)   # odd dims
        pe = pe.unsqueeze(0)                            # (1, max_len, d_model)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        """x: (batch, seq_len, d_model)"""
        x = x + self.pe[:, :x.size(1)]
        return self.dropout(x)


# ──────────────────────────────────────────────────────────────
#  CVAE Encoder  (used only during training)
# ──────────────────────────────────────────────────────────────

class CVAEEncoder(nn.Module):
    """
    Encodes (observation, action_chunk) → (mu, log_var) of latent z.

    During training:  z ~ N(mu, exp(log_var/2))   [reparameterisation]
    During inference: z = 0                         [prior mean]
    """

    def __init__(self, obs_dim: int, action_dim: int, chunk_size: int,
                 latent_dim: int, d_model: int, nhead: int, num_layers: int):
        super().__init__()
        self.chunk_size  = chunk_size
        self.latent_dim  = latent_dim

        # Project observation and each action in the chunk to d_model
        self.obs_proj    = nn.Linear(obs_dim,    d_model)
        self.action_proj = nn.Linear(action_dim, d_model)
        self.pos_enc     = PositionalEncoding(d_model)

        # [CLS] token whose final hidden state is used to predict mu / log_var
        self.cls_token   = nn.Parameter(torch.zeros(1, 1, d_model))

        encoder_layer    = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=0.1, batch_first=True
        )
        self.transformer = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)

        self.fc_mu       = nn.Linear(d_model, latent_dim)
        self.fc_logvar   = nn.Linear(d_model, latent_dim)

    def forward(self, obs: torch.Tensor,
                actions: torch.Tensor) -> Tuple[torch.Tensor, torch.Tensor]:
        """
        Args:
            obs:     (B, obs_dim)
            actions: (B, chunk_size, action_dim)
        Returns:
            mu, log_var: (B, latent_dim) each
        """
        B = obs.size(0)

        # Build token sequence: [CLS, obs_token, action_token_0, ..., action_token_K]
        obs_token    = self.obs_proj(obs).unsqueeze(1)          # (B,1,d)
        action_tokens = self.action_proj(actions)               # (B,K,d)
        cls_tokens   = self.cls_token.expand(B, -1, -1)         # (B,1,d)

        tokens = torch.cat([cls_tokens, obs_token, action_tokens], dim=1)  # (B, K+2, d)
        tokens = self.pos_enc(tokens)
        out    = self.transformer(tokens)                       # (B, K+2, d)

        # Use CLS token output for posterior parameters
        cls_out = out[:, 0]                                     # (B, d)
        mu      = self.fc_mu(cls_out)
        log_var = self.fc_logvar(cls_out)
        return mu, log_var


# ──────────────────────────────────────────────────────────────
#  ACT Policy
# ──────────────────────────────────────────────────────────────

class ACTPolicy(nn.Module):
    """
    Full ACT Policy Network.

    Training forward pass  → predicts action chunk + KL loss
    Inference forward pass → predicts action chunk (z=0)
    """

    def __init__(
        self,
        obs_dim:     int   = 7,
        action_dim:  int   = 3,
        chunk_size:  int   = 10,   # K: number of future actions predicted at once
        d_model:     int   = 128,  # Transformer hidden dimension
        nhead:       int   = 4,    # number of attention heads
        num_enc_layers: int = 3,   # encoder depth
        num_dec_layers: int = 3,   # decoder depth
        latent_dim:  int   = 32,   # CVAE latent dimension
        kl_weight:   float = 10.0, # β in β-VAE; balances reconstruction vs KL
    ):
        super().__init__()

        # ── Store config ──────────────────────────────────────
        self.obs_dim    = obs_dim
        self.action_dim = action_dim
        self.chunk_size = chunk_size
        self.d_model    = d_model
        self.latent_dim = latent_dim
        self.kl_weight  = kl_weight

        # ── Observation encoder ───────────────────────────────
        # Projects raw observation + latent z into token space
        self.obs_encoder = nn.Sequential(
            nn.Linear(obs_dim + latent_dim, d_model * 2),
            nn.ReLU(),
            nn.Linear(d_model * 2, d_model),
        )

        # ── Transformer backbone ──────────────────────────────
        self.pos_enc = PositionalEncoding(d_model)

        enc_layer = nn.TransformerEncoderLayer(
            d_model=d_model, nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=0.1, batch_first=True
        )
        self.transformer_encoder = nn.TransformerEncoder(enc_layer, num_layers=num_enc_layers)

        dec_layer = nn.TransformerDecoderLayer(
            d_model=d_model, nhead=nhead,
            dim_feedforward=d_model * 4,
            dropout=0.1, batch_first=True
        )
        self.transformer_decoder = nn.TransformerDecoder(dec_layer, num_layers=num_dec_layers)

        # ── Query tokens (one per action in the chunk) ────────
        # These are learnable embeddings that query the encoded observation
        self.query_embed = nn.Embedding(chunk_size, d_model)

        # ── Action prediction head ────────────────────────────
        self.action_head = nn.Linear(d_model, action_dim)

        # ── CVAE encoder (training only) ──────────────────────
        self.cvae_encoder = CVAEEncoder(
            obs_dim=obs_dim, action_dim=action_dim,
            chunk_size=chunk_size, latent_dim=latent_dim,
            d_model=d_model, nhead=nhead, num_layers=2
        )

        # ── Initialise weights ────────────────────────────────
        self._init_weights()

    def _init_weights(self):
        for p in self.parameters():
            if p.dim() > 1:
                nn.init.xavier_uniform_(p)

    # ── Reparameterisation trick ──────────────────────────────

    @staticmethod
    def reparameterise(mu: torch.Tensor, log_var: torch.Tensor) -> torch.Tensor:
        """Sample z = mu + eps * std  (eps ~ N(0,I))."""
        std = torch.exp(0.5 * log_var)
        eps = torch.randn_like(std)
        return mu + eps * std

    # ── Core forward ─────────────────────────────────────────

    def forward(
        self,
        obs:            torch.Tensor,
        actions:        Optional[torch.Tensor] = None,
        is_training:    bool = True,
    ) -> Tuple[torch.Tensor, Optional[torch.Tensor]]:
        """
        Args:
            obs:         (B, obs_dim)         — current observation
            actions:     (B, chunk_size, act_dim) — ground-truth chunk (train only)
            is_training: use CVAE encoder when True, z=0 when False

        Returns:
            pred_actions: (B, chunk_size, act_dim)
            kl_loss:      scalar tensor (None during inference)
        """
        B = obs.size(0)

        # ── 1. Obtain latent z ────────────────────────────────
        if is_training and actions is not None:
            mu, log_var = self.cvae_encoder(obs, actions)
            z = self.reparameterise(mu, log_var)
            # KL divergence vs. standard normal N(0,I)
            kl_loss = -0.5 * torch.mean(1 + log_var - mu.pow(2) - log_var.exp())
        else:
            # Inference: use prior mean z = 0
            z       = torch.zeros(B, self.latent_dim, device=obs.device)
            kl_loss = None

        # ── 2. Encode observation + z ─────────────────────────
        obs_z        = torch.cat([obs, z], dim=-1)          # (B, obs_dim + latent_dim)
        obs_token    = self.obs_encoder(obs_z).unsqueeze(1) # (B, 1, d_model)
        obs_token    = self.pos_enc(obs_token)
        memory       = self.transformer_encoder(obs_token)  # (B, 1, d_model)

        # ── 3. Decode: query tokens attend to encoded obs ─────
        query_indices = torch.arange(self.chunk_size, device=obs.device)
        queries       = self.query_embed(query_indices)     # (chunk_size, d_model)
        queries       = queries.unsqueeze(0).expand(B, -1, -1)  # (B, K, d_model)
        queries       = self.pos_enc(queries)

        decoded = self.transformer_decoder(
            tgt=queries,   # (B, K, d_model)
            memory=memory  # (B, 1, d_model)
        )                  # (B, K, d_model)

        # ── 4. Project to action space ────────────────────────
        pred_actions = self.action_head(decoded)            # (B, K, action_dim)
        pred_actions = torch.tanh(pred_actions)             # bound to (-1, 1)

        return pred_actions, kl_loss

    # ── Convenience inference method ─────────────────────────

    @torch.no_grad()
    def predict(self, obs: torch.Tensor) -> torch.Tensor:
        """
        Single-sample inference.
        Args:  obs (obs_dim,) or (1, obs_dim)
        Returns: action_chunk (chunk_size, action_dim)
        """
        self.eval()
        if obs.dim() == 1:
            obs = obs.unsqueeze(0)
        pred, _ = self.forward(obs, is_training=False)
        return pred.squeeze(0)   # (chunk_size, action_dim)
