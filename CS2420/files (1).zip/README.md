# EgoMimic Level 1 — ACT Behavior Cloning Reproduction

> A lightweight reproduction of the **Action Chunking with Transformers (ACT)** policy backbone,  
> the core architecture underlying the [EgoMimic](https://egomimic.github.io/) framework (GT RL2 Lab, Danfei Xu).

---

## Motivation

EgoMimic trains robot manipulation policies from **egocentric human demonstrations** collected with Apple Vision Pro.  
Its policy backbone is **ACT** (Zhao et al., RSS 2023): a Transformer-based architecture that predicts
a *chunk* of K future actions at once, rather than one action at a time.

This experiment reproduces ACT in a self-contained 2-D Pick-and-Place simulation to:
1. Validate the architecture's core learning mechanism (Behavior Cloning with CVAE)
2. Compare two execution strategies: **first-action** vs **full-chunk**
3. Establish a baseline for Level 2 experiments (viewpoint domain gap analysis)

---

## Project Structure

```
EgoMimic_Level1/
├── environment.py      # Lightweight 2-D Pick-and-Place env + scripted expert
├── act_model.py        # ACT policy: Transformer encoder-decoder + CVAE
├── collect_data.py     # Generate expert demonstration dataset
├── train.py            # Behavior Cloning training loop
├── evaluate.py         # Quantitative evaluation + plots
├── setup.sh            # One-command dependency installation
├── data/               # (generated) expert_demos.npz
├── checkpoints/        # (generated) best_model.pt
└── results/            # (generated) plots + eval_report.md
```

---

## Quick Start

```bash
# 1. Install dependencies (Python 3.8+)
bash setup.sh
source egomimic_level1/bin/activate

# 2. Collect 2000 expert demonstrations
python3 collect_data.py

# 3. Train ACT policy (~5 min on CPU)
python3 train.py

# 4. Evaluate and generate plots
python3 evaluate.py
```

---

## Architecture Overview

```
Observation (7-dim)
       │
       ▼
  ObsEncoder (MLP)          ← obs + latent z concatenated
       │
       ▼
Transformer Encoder         ← self-attention over obs token
       │  (memory)
       ▼
Transformer Decoder  ◄──── Query Embeddings (K learnable tokens)
       │
       ▼
  Action Head (Linear)
       │
       ▼
Predicted Action Chunk      ← K actions at once (tanh-bounded)
      (K × 3)
```

**CVAE (training only):**
```
(obs, action_chunk) → Transformer → [CLS] → (μ, log σ²)
z = μ + ε·σ    [reparameterisation trick]

Loss = MSE(pred_chunk, gt_chunk) + β · KL(q(z|obs,a) ‖ p(z))
```

**At inference:** z = 0 (prior mean), no CVAE needed.

---

## Key Concepts Demonstrated

| Concept | Where in Code | Connection to EgoMimic |
|---------|--------------|------------------------|
| Action Chunking | `act_model.py` → `chunk_size` | Core ACT innovation; EgoMimic uses K=100 |
| CVAE Latent | `CVAEEncoder`, `reparameterise()` | Models multi-modal demonstrations |
| Behavior Cloning | `train.py` → `L_total` | EgoMimic scales this to real robot data |
| Positional Encoding | `PositionalEncoding` | Enables temporal ordering of chunk tokens |
| Full-chunk Execution | `evaluate.py` → `ACTPolicyWrapper` | Reduces jitter vs per-step re-query |

---

## Expected Results

```
──────────────────────────────────────────────────────────────
 Policy               Success Rate   Avg Steps   Avg Reward
──────────────────────────────────────────────────────────────
 Expert (scripted)        ~98%          ~35         ~0.85
 ACT (first-action)       ~75%          ~45         ~0.60
 ACT (full-chunk)         ~82%          ~42         ~0.68
──────────────────────────────────────────────────────────────
```

The ~16% gap between Expert and ACT illustrates the **compounding error problem** in Behavior Cloning,  
the main motivation for more advanced IL algorithms like DAgger or GAIL.

---

## Discussion: Why the Gap Exists

1. **Distributional shift**: At training time, the policy always sees expert observations.  
   At test time, small errors accumulate, leading to states never seen during training.

2. **Single-observation conditioning**: The policy has no memory — it can only see `obs_t`.  
   A partially-grasped object looks different from a cleanly-grasped one, confusing the policy.

3. **Full-chunk beats first-action** because committing to a consistent sequence of K actions  
   avoids oscillatory behavior from re-querying a stochastic policy every step.

---

## Connection to Level 2

The next experiment quantifies the **viewpoint domain gap**:

- Train on robot-perspective data → evaluate on robot-perspective → baseline
- Train on egocentric-perspective data → evaluate on robot-perspective → gap
- Train with viewpoint alignment augmentation → evaluate on robot-perspective → recovery

This directly replicates EgoMimic's core research question.

---

## References

- **EgoMimic**: Kareer et al., "EgoMimic: Scaling Imitation Learning via Egocentric Video", CoRL 2024  
- **ACT**: Zhao et al., "Learning Fine-Grained Bimanual Manipulation with Low-Cost Hardware", RSS 2023  
- **Behavior Cloning**: Pomerleau, "ALVINN: An Autonomous Land Vehicle in a Neural Network", NeurIPS 1988

---

*This experiment was conducted as part of a self-directed study of the EgoMimic framework,  
motivated by research interest in Embodied AI and the RL2 Lab at Georgia Tech (Prof. Danfei Xu).*
