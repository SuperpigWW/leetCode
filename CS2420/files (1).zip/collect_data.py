"""
collect_data.py
===============
Collect expert demonstrations using the scripted ExpertPolicy.

What this script does
---------------------
1. Runs N episodes of the Pick-and-Place env with the scripted expert.
2. Saves every (observation, action_chunk) pair as a dataset.
3. Prints statistics (success rate, avg episode length, etc.).

Output
------
  data/
    expert_demos.npz   — numpy archive used by train.py
    demo_stats.txt     — human-readable collection stats

Understanding "action chunks" (key EgoMimic concept)
------------------------------------------------------
Instead of saving single (obs, action) pairs, we save
(obs_t, [action_t, action_t+1, ..., action_t+K-1]) tuples.

This forces the policy to commit to a sequence of future actions,
which smooths trajectories and is the core innovation of ACT.
If the episode ends before K steps remain, we pad with the last action.
"""

import os
import numpy as np
from tqdm import tqdm
from environment import PickAndPlaceEnv, ExpertPolicy, EnvConfig

# ── Config ────────────────────────────────────────────────────
NUM_EPISODES  = 2000   # total demonstrations to collect
CHUNK_SIZE    = 10     # K: actions predicted per forward pass
NOISE_STD     = 0.02   # small noise on expert actions (data diversity)
SAVE_DIR      = "data"
SAVE_PATH     = os.path.join(SAVE_DIR, "expert_demos.npz")
STATS_PATH    = os.path.join(SAVE_DIR, "demo_stats.txt")
# ─────────────────────────────────────────────────────────────


def collect_episode(env: PickAndPlaceEnv, expert: ExpertPolicy):
    """
    Run one episode and return lists of observations and actions.

    Returns:
        observations: list of np.ndarray (obs_dim,)
        actions:      list of np.ndarray (action_dim,)
        success:      bool
    """
    obs = env.reset()
    expert.reset()

    observations = []
    actions_list = []
    done = False

    while not done:
        action = expert.act(obs)
        observations.append(obs.copy())
        actions_list.append(action.copy())
        obs, _, done, info = env.step(action)

    return observations, actions_list, info["success"]


def build_chunked_dataset(all_obs, all_actions, chunk_size):
    """
    Convert flat lists of (obs, action) into chunked pairs.

    For each timestep t, the sample is:
      input:  obs[t]
      target: [action[t], action[t+1], ..., action[t+K-1]]
    If the episode ends early, pad remaining slots with the final action.

    Args:
        all_obs:     list of episodes, each episode is list of obs arrays
        all_actions: list of episodes, each episode is list of action arrays
        chunk_size:  K

    Returns:
        obs_array:    (N, obs_dim)
        chunk_array:  (N, chunk_size, action_dim)
    """
    obs_list   = []
    chunk_list = []

    for ep_obs, ep_act in zip(all_obs, all_actions):
        T = len(ep_obs)
        for t in range(T):
            # Build action chunk with padding if needed
            chunk = []
            for k in range(chunk_size):
                idx = min(t + k, T - 1)   # clamp to last action
                chunk.append(ep_act[idx])
            obs_list.append(ep_obs[t])
            chunk_list.append(np.stack(chunk, axis=0))  # (K, action_dim)

    return np.array(obs_list, dtype=np.float32), \
           np.array(chunk_list, dtype=np.float32)


def main():
    os.makedirs(SAVE_DIR, exist_ok=True)

    env    = PickAndPlaceEnv(EnvConfig(seed=0))
    expert = ExpertPolicy(noise_std=NOISE_STD)

    all_obs     = []
    all_actions = []
    successes   = []
    ep_lengths  = []

    print(f"Collecting {NUM_EPISODES} expert demonstrations...")
    print(f"  Chunk size K = {CHUNK_SIZE}")
    print(f"  Expert noise σ = {NOISE_STD}")
    print()

    for ep in tqdm(range(NUM_EPISODES), desc="Collecting"):
        obs_ep, act_ep, success = collect_episode(env, expert)
        all_obs.append(obs_ep)
        all_actions.append(act_ep)
        successes.append(success)
        ep_lengths.append(len(obs_ep))

    # ── Statistics ────────────────────────────────────────────
    success_rate  = np.mean(successes) * 100
    avg_length    = np.mean(ep_lengths)
    total_steps   = sum(ep_lengths)

    stats_lines = [
        "=" * 50,
        "  Expert Demonstration Collection Stats",
        "=" * 50,
        f"  Episodes collected : {NUM_EPISODES}",
        f"  Expert success rate: {success_rate:.1f}%",
        f"  Avg episode length : {avg_length:.1f} steps",
        f"  Total timesteps    : {total_steps}",
        f"  Chunk size (K)     : {CHUNK_SIZE}",
        f"  Expert noise σ     : {NOISE_STD}",
        "=" * 50,
    ]
    for line in stats_lines:
        print(line)

    with open(STATS_PATH, "w") as f:
        f.write("\n".join(stats_lines))

    # ── Build chunked dataset ─────────────────────────────────
    print("\nBuilding chunked dataset...")
    obs_arr, chunk_arr = build_chunked_dataset(all_obs, all_actions, CHUNK_SIZE)

    print(f"  obs_arr shape   : {obs_arr.shape}")    # (N, 7)
    print(f"  chunk_arr shape : {chunk_arr.shape}")  # (N, K, 3)

    # Normalise observations to zero mean, unit std for stable training
    obs_mean = obs_arr.mean(axis=0)
    obs_std  = obs_arr.std(axis=0) + 1e-8

    # ── Save ──────────────────────────────────────────────────
    np.savez(
        SAVE_PATH,
        observations  = obs_arr,
        action_chunks = chunk_arr,
        obs_mean      = obs_mean,
        obs_std       = obs_std,
        success_rate  = np.array([success_rate]),
        chunk_size    = np.array([CHUNK_SIZE]),
    )
    print(f"\n✅ Dataset saved to: {SAVE_PATH}")
    print(f"   Stats saved to:   {STATS_PATH}")


if __name__ == "__main__":
    main()
